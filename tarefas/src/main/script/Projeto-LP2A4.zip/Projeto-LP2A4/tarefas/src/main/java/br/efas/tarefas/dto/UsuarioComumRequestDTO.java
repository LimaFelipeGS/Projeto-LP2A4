package br.efas.tarefas.dto;

public record UsuarioComumRequestDTO(String nome) {
}
