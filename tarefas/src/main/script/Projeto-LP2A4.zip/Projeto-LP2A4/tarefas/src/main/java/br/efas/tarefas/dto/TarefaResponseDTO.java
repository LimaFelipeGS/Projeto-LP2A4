package br.efas.tarefas.dto;

import br.efas.tarefas.model.Tarefa;

import java.time.LocalDateTime;
import java.util.Date;

public record TarefaResponseDTO(Long id, String nome, LocalDateTime data, String descricao) {
    public TarefaResponseDTO(Tarefa tarefa) {
        this(tarefa.getId(), tarefa.getNome(), tarefa.getData(), tarefa.getDescricao());
    }
}
